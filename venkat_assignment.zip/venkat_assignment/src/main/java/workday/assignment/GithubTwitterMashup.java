package workday.assignment;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Properties;

import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * @author venkat
 *
 */
public class GithubTwitterMashup {
	private final String CONSUMER_KEY = "consumer_key";
	private final String CONSUMER_SECRET = "consumer_secret";
	private final String KEY_SECRET_RESOURCE = "/keysecret.config.properties";
	
	private final String GITHUB_REPO_SEARCH_URL = "https://api.github.com/search/repositories"; 
		
	private final String TWITTER_TOKEN_URL = "https://api.twitter.com/oauth2/token"; 
	private final String TWITTER_SEARCH_URL = "https://api.twitter.com/1.1/search/tweets.json";
	
	private static final Logger logger = LogManager.getLogger(GithubTwitterMashup.class);
	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
	private final Properties properties = new Properties();

	private int maxProjectsToGetTweets = 10;

	/**
	 * This is the starting method to get projects and their tweets from github and twitter
	 * 
	 * @param searchKeyword the keyword used to seach the projects in github (example: "reactive")
	 * @return	the gson library json array representing a json object with project and tweets.
	 * @throws IOException in case anything goes wrong with IO, it throws exception
	 */
	public JsonArray getProjectsAndTweets(String searchKeyword) throws IOException  {
		logger.info("begin getProjectsAndTweets for keyword: " + searchKeyword);
		JsonArray retJsonProjectsArr = getGithubProjects(searchKeyword);
		
		int projectCount = 0;
		for(JsonElement el: retJsonProjectsArr) {
			JsonObject jsonProject = el.getAsJsonObject();
			
			String projectName = jsonProject.get("name").getAsString();
			JsonArray jsonProjectTweets = getTweetsForProject(projectName);
			
			jsonProject.add("project_tweets", jsonProjectTweets);
			if(++projectCount >= maxProjectsToGetTweets) break;
		}
		logger.info("getProjectsAndTweets successful for keyword: " + searchKeyword + " got count: " + retJsonProjectsArr.size());
		return retJsonProjectsArr;
	}

	/**
	 * Gets projects from github 
	 * 
	 * @param searchKeyword the keyword used to search the projects in github (example: "reactive")
	 * @return the gson library json array representing a json object with projects.
	 * @throws IOException in case anything goes wrong with IO, it throws exception
	 */
	public JsonArray getGithubProjects(String searchKeyword) throws IOException  {
		logger.info("begin getGithubProjects for keyword: " + searchKeyword);
		JsonArray retJsonProjectsArr = new JsonArray();
		
		HttpGet httpGet = new HttpGet(GITHUB_REPO_SEARCH_URL + "?q=" + searchKeyword);
		String json = getHttpResponse(httpGet);;
		
		JsonObject projectsObj = gson.fromJson(json, JsonObject.class);
		JsonArray projectsArr = projectsObj.get("items").getAsJsonArray();
		for(JsonElement el: projectsArr) {
			JsonObject retJsonProject = new JsonObject();
			
			JsonObject project = el.getAsJsonObject();
			
			retJsonProject.add("name", project.get("name"));
			retJsonProject.add("description", project.get("description"));
			
			retJsonProjectsArr.add(retJsonProject);
		}
		logger.info("getGithubProjects successful for keyword: " + searchKeyword + " got count: " + retJsonProjectsArr.size());
		return retJsonProjectsArr;
	}
	
	/**
	 * Get tweets from twitter for a project
	 * 
	 * @param projectName github project name for which tweets are to be retrieved
	 * @return the gson library json array representing a json object with tweets of the given project.
	 * @throws IOException in case anything goes wrong with IO, it throws exception
	 */
	public JsonArray getTweetsForProject(String projectName) throws IOException  {
		logger.info("begin getTweetsForProject for project : " + projectName);
		JsonArray retJsonProjectTweets = new JsonArray();
		String accessToken = getAccessToken();
		
		String queryStr = URLEncoder.encode(projectName + " OR #" + projectName, "UTF-8") + "&result_type=recent&count=5";
		HttpGet httpGet = new HttpGet(TWITTER_SEARCH_URL + "?q=" + queryStr);
		httpGet.setHeader("Authorization", "Bearer " + accessToken);
		
		String json = getHttpResponse(httpGet);;
		JsonObject tweetsObj = gson.fromJson(json, JsonObject.class);
		JsonArray tweetsArr = tweetsObj.get("statuses").getAsJsonArray();
		for(JsonElement tweetEntry: tweetsArr) {
			JsonObject retJsonTweet = new JsonObject();
			
			JsonObject tweetObj = tweetEntry.getAsJsonObject();
			JsonObject userObj = tweetObj.get("user").getAsJsonObject();
			
			retJsonTweet.add("name", userObj.get("name"));
			retJsonTweet.add("screen_name", userObj.get("screen_name"));
			retJsonTweet.add("created_at", tweetObj.get("created_at"));
			retJsonTweet.add("text", tweetObj.get("text"));
			
			retJsonProjectTweets.add(retJsonTweet);
		}
		logger.info("getTweetsForProject successful for project : " + projectName + " got count: " + retJsonProjectTweets.size());
		return retJsonProjectTweets;
	}
	
	/**
	 * Get access token based on the key and secret from preferences
	 * 
	 * @return access token for from twitter for the key and secret specified in the keysecret.config.properties file
	 * @throws IOException in case anything goes wrong with IO, it throws exception
	 */
	private String getAccessToken() throws IOException  {
		logger.info("begin getAccessToken");
		
		String consumerKey = properties.getProperty(CONSUMER_KEY);
		String consumerSecret = properties.getProperty(CONSUMER_SECRET);
		
		String encoded = null;
		try {
			encoded = URLEncoder.encode(consumerKey, "UTF-8") + ":" + URLEncoder.encode(consumerSecret, "UTF-8");
		} catch(UnsupportedEncodingException e) {
			logger.error("Error with encode in getAccessToken", e);
			throw e;
		}
		
		String basic = null;
		try {
			basic = DatatypeConverter.printBase64Binary(encoded.getBytes("UTF-8"));
		} catch(UnsupportedEncodingException e) {
			logger.error("Error with base64 in getAccessToken", e);
			throw e;
		}
		
		String accessToken = null;
		HttpPost httpPost = new HttpPost(TWITTER_TOKEN_URL);
		httpPost.setHeader("Authorization", "Basic " + basic);
		httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
		StringEntity bodyEntity = new StringEntity("grant_type=client_credentials");
		httpPost.setEntity(bodyEntity);
		
		String json = getHttpResponse(httpPost);
		JsonObject tokenObj = gson.fromJson(json, JsonObject.class);
		if(tokenObj.get("token_type") != null && tokenObj.get("token_type").getAsString().equals("bearer")) {
			accessToken = tokenObj.get("access_token").getAsString();
		} else {
			logger.error("Cannot get access_token from twitter. " + convertToJson(tokenObj));
			throw new IOException(convertToJson(tokenObj));
		}
		return accessToken;
	}
	
	/**
	 * Utility method to execute http requests (GET, POSTs)
	 * 
	 * @param httpRequest the http request which has to be executed
	 * @return entire http response for the given request
	 * @throws IOException in case anything goes wrong with IO, it throws exception
	 */
	private String getHttpResponse(HttpRequestBase httpRequest) throws IOException  {
		logger.info("begin getHttpEntity");
		
		String httpResp = null;
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			logger.info("Executing request " + httpRequest.getRequestLine());
			CloseableHttpResponse response = httpclient.execute(httpRequest);
			try {
				logger.info(response.getStatusLine());
				
				// Get hold of the response entity
				HttpEntity httpEntity = response.getEntity();
				httpResp = EntityUtils.toString(httpEntity);
			} finally {
				response.close();
			}
		} finally {
			httpclient.close();
		}
		logger.info("getHttpEntity successful");
		return httpResp;
	}
	
	/**
	 * Loads twitter key and secret from a resource on the classpath
	 * 
	 * @param keySecretResource name of the resource from which key and secret are to be read
	 * @throws IOException in case resource is missing or malformed, it throws exception
	 */
	public void loadProperties(String keySecretResource) throws IOException {
		logger.info("begin loadProperties from resource " + keySecretResource);
		try(InputStream is = this.getClass().getResourceAsStream(keySecretResource)) {
			if(is == null) {
				throw new IOException("Missing in resource " + keySecretResource);
			}
			properties.load(is);
		}
		if(properties.getProperty(CONSUMER_KEY) == null || properties.getProperty(CONSUMER_SECRET) == null) {
			throw new IOException(CONSUMER_KEY + " or " + CONSUMER_SECRET + " missing in resource " + keySecretResource + ".\n" +
					"The resource should contain the following entries:\n" +
					"consumer_key=<twitter-consumer_key>\n" +
					"consumer_secret=<twitter-consumer_secret>");
		}
		logger.info("loadProperties successful from resource " + keySecretResource);
	}
	
	private String convertToJson(JsonElement el) {
		return el == null ? null : gson.toJson(el);
	}

	/**
	 * Initializes the this object by loading the preferences
	 * @throws IOException in case of failure while reading the preferences
	 */
	public void initialize() throws IOException {
		logger.info("begin initialize");
		try {
			loadProperties(KEY_SECRET_RESOURCE);
		} catch(IOException e) {
			logger.error("Exception in initialize", e);
			throw e;
		}
		logger.info("initialize successful");
	}
	
	public static void main(String[] args) throws IOException {
		
		GithubTwitterMashup cmd = new GithubTwitterMashup();
		try {
			//Initialize the command with passed args
			cmd.initialize();
			
			//Get projects and tweets for them for the keyword "reactive"
			JsonArray jsonProjectsAndTweets = cmd.getProjectsAndTweets("reactive");
			
			//Pretty print projects and tweets.
			System.out.println(cmd.convertToJson(jsonProjectsAndTweets));
		} catch(IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
