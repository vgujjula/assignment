package workday.assignment;

import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for GithubTwitterMashup.
 */
public class GithubTwitterMashupTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public GithubTwitterMashupTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( GithubTwitterMashupTest.class );
    }

    @BeforeClass
    public void testBeforeClass() {
    	//System.out.println("BeforeClass");
    }
    
    @Before
    public void testBefore() {
    	//System.out.println("Before");
    }

    @After
    public void testAfter() {
    	//System.out.println("After");
    }
    
    @AfterClass
    public void testAfterClass() {
    	//System.out.println("AfterClass");
    }
    
    public void testEmptyKeySecretFile()
    {
    	GithubTwitterMashup cmd = new GithubTwitterMashup();
    	try {
    		cmd.loadProperties("/empty-keysecret.config.properties");
    	} catch(IOException e) {
    		String expectedError = "consumer_key or consumer_secret missing in resource /empty-keysecret.config.properties.\n" +
    				"The resource should contain the following entries:\n" +
    				"consumer_key=<twitter-consumer_key>\n" +
    				"consumer_secret=<twitter-consumer_secret>";
    		assertEquals(expectedError, e.getMessage());
    		return;
    	}
        assertTrue( false );
    }

    public void testNonExistentKeySecretFile()
    {
    	GithubTwitterMashup cmd = new GithubTwitterMashup();
    	try {
    		cmd.loadProperties("/non-existent-file.properties");
    	} catch(IOException e) {
    		assertEquals("Missing in resource /non-existent-file.properties", e.getMessage());
    		return;
    	}
        assertTrue( false );
    }
    
}
