#compile the program
javac -cp lib/apache-log4j-2.5-bin/lib/log4j-api-2.5.jar:lib/apache-log4j-2.5-bin/lib/log4j-core-2.5.jar:lib/gson/lib/gson-2.6.2.jar:lib/httpcomponents-client-4.5.2/lib/commons-codec-1.9.jar:lib/httpcomponents-client-4.5.2/lib/commons-logging-1.2.jar:lib/httpcomponents-client-4.5.2/lib/fluent-hc-4.5.2.jar:lib/httpcomponents-client-4.5.2/lib/httpclient-4.5.2.jar:lib/httpcomponents-client-4.5.2/lib/httpclient-cache-4.5.2.jar:lib/httpcomponents-client-4.5.2/lib/httpclient-win-4.5.2.jar:lib/httpcomponents-client-4.5.2/lib/httpcore-4.4.4.jar:lib/httpcomponents-client-4.5.2/lib/httpmime-4.5.2.jar:lib/httpcomponents-client-4.5.2/lib/jna-4.1.0.jar:lib/httpcomponents-client-4.5.2/lib/jna-platform-4.1.0.jar:lib/junit/lib/hamcrest-core-1.1.jar:lib/junit/lib/junit-4.10.jar src/main/java/workday/assignment/GithubTwitterMashup.java src/test/java/workday/assignment/GithubTwitterMashupTest.java src/test/java/workday/assignment/JunitTestSuiteRunner.java -d bin

#copy all the resources to the classpath
cp -r src/main/resources/* bin/


